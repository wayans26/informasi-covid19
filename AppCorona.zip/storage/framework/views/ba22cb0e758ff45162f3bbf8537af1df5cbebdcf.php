<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Covid19</title>
    <!--favicon-->
    <link rel="icon" href="<?php echo e(asset('admin/images/favicon.ico')); ?>" type="image/x-icon">
    <!-- simplebar CSS-->
    <link href="<?php echo e(asset('admin/plugins/simplebar/css/simplebar.css')); ?>" rel="stylesheet" />
    <!-- Bootstrap core CSS-->
    <link href="<?php echo e(asset('admin/css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <!-- animate CSS-->
    <link href="<?php echo e(asset('admin/css/animate.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Icons CSS-->
    <link href="<?php echo e(asset('admin/css/icons.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Sidebar CSS-->
    <link href="<?php echo e(asset('admin/css/sidebar-menu.css')); ?>" rel="stylesheet" />
    <!-- Custom Style-->
    <link href="<?php echo e(asset('admin/css/app-style.css')); ?>" rel="stylesheet" />


    
    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo e(asset('admin/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/bootstrap.min.js')); ?>"></script>

    <!-- simplebar js -->
    <script src="<?php echo e(asset('admin/plugins/simplebar/js/simplebar.js')); ?>"></script>
    <!-- waves effect js -->
    <script src="<?php echo e(asset('admin/js/waves.js')); ?>"></script>
    <!-- sidebar-menu js -->
    <script src="<?php echo e(asset('admin/js/sidebar-menu.js')); ?>"></script>
    <!-- Custom scripts -->
    <script src="<?php echo e(asset('admin/js/app-script.js')); ?>"></script>
    <!-- Chart js -->
    <script src="<?php echo e(asset('admin/plugins/Chart.js/Chart.min.js')); ?>"></script>
    <!--Peity Chart -->
    <script src="<?php echo e(asset('admin/plugins/peity/jquery.peity.min.js')); ?>"></script>


</head>

<body>

    <!-- Start wrapper-->
    <div id="wrapper">

        <div class="clearfix"></div>

        <div class="">
            <div class="container-fluid">

                <?php $__env->startSection('konten'); ?>

                <?php echo $__env->yieldSection(); ?>

            </div>
            <!-- End container-fluid-->
        </div>
        <!--End content-wrapper-->
        <!--Start Back To Top Button-->
        <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
        <!--End Back To Top Button-->

        <!--Start footer-->
        <footer class="footer">
            <div class="container">
                <div class="text-center">
                    Copyright © <script>
                        document.write(new Date().getFullYear())

                    </script> Wayan Setiawan
                </div>
            </div>
        </footer>
        <!--End footer-->
    </div>
    <!--End wrapper-->
</body>

</html>
<?php /**PATH D:\Appcorona\AppCorona\resources\views/master.blade.php ENDPATH**/ ?>