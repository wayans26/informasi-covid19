<!--Start sidebar-wrapper-->
<div id="sidebar-wrapper" data-simplebar="" data-simplebar-auto-hide="true">
    <div class="brand-logo">
        <a href="index.html">
            <img src="admin/images/logo-icon.png" class="logo-icon" alt="logo icon">
            <h5 class="logo-text">Rukada Admin</h5>
        </a>
    </div>
    <ul class="sidebar-menu do-nicescrol">
        <li class="sidebar-header">MAIN NAVIGATION</li>
        <li class="active">
            <a href="/" class="waves-effect">
                <i class="zmdi zmdi-view-dashboard"></i> <span>Dashboard</span> </a>
        </li>
    </ul>

</div>
<!--End sidebar-wrapper--><?php /**PATH D:\Appcorona\AppCorona\resources\views/menus.blade.php ENDPATH**/ ?>